# Importamos mysite para la interacción con la base de datos
import pymysql

# Importamos la dependencia de pymysql para la conexión con la base de datos


# Configuramos la conexión con la base de datos
pymysql.install_as_MySQLdb()
