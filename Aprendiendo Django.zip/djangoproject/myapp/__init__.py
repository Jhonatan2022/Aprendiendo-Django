# Este archivo es necesario para que Django reconozca este directorio como un módulo de Python
# Y hace que django reconozca que este directorio es un módulo de Python