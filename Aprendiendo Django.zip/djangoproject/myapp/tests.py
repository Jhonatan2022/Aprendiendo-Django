# Este archibo nos permitira crear pruebas unitarias para nuestra aplicación

from django.test import TestCase

# Create your tests here.
