# By learning - Django
<img src="https://raw.githubusercontent.com/MicaelliMedeiros/micaellimedeiros/master/image/computer-illustration.png" min-width="400px" max-width="400px" width="400px" align="right" alt="Computador iuriCode">

<p align="left"> 
  In this repository I will learn how to use the Django framework.
</p>

<p align="left">
  🦄 Language: <strong>Python</strong>
</p>

<p align="left">
  💼 Tools: <strong>Visual Studio Code, Framework - Django, documentatión and videos.</strong>
</p>

<p align="left">
  💌 To contact me:
</p>

<p align="left">
  <a href="#" alt="Gmail">
  <img src="https://img.shields.io/badge/-Gmail-FF0000?style=flat-square&labelColor=FF0000&logo=gmail&logoColor=white&link="https://mail.google.com/mail/u/0/#inbox/"></a>
</p>  
